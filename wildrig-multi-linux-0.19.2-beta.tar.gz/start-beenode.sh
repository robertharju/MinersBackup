#!/bin/bash

while true
do
./wildrig-multi --print-full --algo honeycomb --opencl-threads auto --opencl-launch auto --url stratum+tcp://pool.rplant.xyz:7018 --user B9Fc2oJMRyBMLTaJDEmsjPXZ7kHrfYcGMF.Donate --pass x
sleep 5
done
