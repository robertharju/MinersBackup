#!/bin/bash

while true
do
./wildrig-multi --print-full --algo lyra2v3 --opencl-threads auto --opencl-launch auto --url stratum+tcp://eu.bsod.pw:2536 --user VpFak1DnfAMUKEosDmzAxZFACvKtndVxbi --pass c=VTC
sleep 5
done
